<?php

/**
 * Hook, filter, etc should goes here
 */

/**
 * error handling sample
 *
 * $app->error(function() use ($app){
 *     $app->render('error.html');
 * });
 */

