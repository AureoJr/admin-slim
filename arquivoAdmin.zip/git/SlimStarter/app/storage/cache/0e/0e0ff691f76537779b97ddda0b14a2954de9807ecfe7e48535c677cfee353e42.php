<?php

/* @usergroup/group/index.twig */
class __TwigTemplate_24140b4ce09b9c004f3cdae631275d7240d8f34fa639b6234a9ae5ef2b033317 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("admin/index.twig", "@usergroup/group/index.twig", 1);
        $this->blocks = array(
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "admin/index.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_content($context, array $blocks = array())
    {
        // line 3
        echo "<div class=\"row page-header-box\">
    <div class=\"col-xs-10\">
        <h3>";
        // line 5
        echo twig_escape_filter($this->env, (isset($context["title"]) ? $context["title"] : null), "html", null, true);
        echo "</h3>
    </div>
    <div class=\"col-xs-2\">
        <a href=\"#\" id=\"btn-user-add\" class=\"btn btn-success btn-sm pull-right\"><i class=\"fa fa-plus\"></i> Add Group</a>
    </div>
</div>
";
    }

    public function getTemplateName()
    {
        return "@usergroup/group/index.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  35 => 5,  31 => 3,  28 => 2,  11 => 1,);
    }
}
/* {% extends 'admin/index.twig' %}*/
/* {% block content %}*/
/* <div class="row page-header-box">*/
/*     <div class="col-xs-10">*/
/*         <h3>{{ title }}</h3>*/
/*     </div>*/
/*     <div class="col-xs-2">*/
/*         <a href="#" id="btn-user-add" class="btn btn-success btn-sm pull-right"><i class="fa fa-plus"></i> Add Group</a>*/
/*     </div>*/
/* </div>*/
/* {% endblock %}*/
