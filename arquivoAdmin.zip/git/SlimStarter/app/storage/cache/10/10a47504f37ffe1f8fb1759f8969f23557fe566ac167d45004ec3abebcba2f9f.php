<?php

/* admin/login.twig */
class __TwigTemplate_d1e99f6aabc32d92dff2835f2bbcc176f155bc83214d82bd8745e1f6707f80ea extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("master.twig", "admin/login.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "master.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        // line 4
        echo "<style type=\"text/css\">
  body {
    background-color: #DADADA;
  }
  body > .grid {
    height: 100%;
  }
  .image {
    margin-top: -100px;
  }
  .column {
    max-width: 450px;
  }
</style>
<div class=\"ui middle aligned center aligned grid\">
  <div class=\"column\">
    <h2 class=\"ui teal image header\">
      <img src=\"assets/images/logo.png\" class=\"image\">
      <div class=\"content\">
        Acesse sua conta
      </div>
    </h2>
    <form class=\"ui large form\" method=\"post\" action=\"";
        // line 26
        echo twig_escape_filter($this->env, $this->env->getExtension('slim')->base(), "html", null, true);
        echo "/login\" >
      <input type=\"hidden\" name=\"redirect\" value=\"";
        // line 27
        echo twig_escape_filter($this->env, (($this->getAttribute((isset($context["flash"]) ? $context["flash"] : null), "redirect", array())) ? ($this->getAttribute((isset($context["flash"]) ? $context["flash"] : null), "redirect", array())) : ((isset($context["redirect"]) ? $context["redirect"] : null))), "html", null, true);
        echo "\">
      <div class=\"ui stacked segment\">
        <div class=\"field\">
          <div class=\"ui left icon input\">
            <i class=\"user icon\"></i>
            <input type=\"text\" name=\"email\" placeholder=\"E-mail\">
          </div>
        </div>
        <div class=\"field\">
          <div class=\"ui left icon input\">
            <i class=\"lock icon\"></i>
            <input type=\"password\" name=\"password\" placeholder=\"Senha\">
          </div>
        </div>
        <div class=\"ui fluid large teal submit button\">Login</div>
      </div>

      <div class=\"ui error message\"></div>

    </form>
    ";
        // line 47
        if ($this->getAttribute((isset($context["flash"]) ? $context["flash"] : null), "message", array())) {
            // line 48
            echo "    <div class=\"ui warning message \" style=\"margin-top: 25px\">
        <i class=\"close icon\"></i>
        <p>
          ";
            // line 51
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["flash"]) ? $context["flash"] : null), "message", array()), "html", null, true);
            echo "
        </p>
    </div>
    ";
        }
        // line 55
        echo "    <input name=\"remember\" type=\"checkbox\" value=\"Remember Me\" ";
        if ($this->getAttribute((isset($context["flash"]) ? $context["flash"] : null), "remember", array())) {
            echo "checked";
        }
        echo ">Remember Me
    <div class=\"ui message\">
      Esqueceu a senha ? <a href=\"/resetpass\">Clique aqui</a>
    </div>
  </div>
</div>

";
    }

    public function getTemplateName()
    {
        return "admin/login.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  96 => 55,  89 => 51,  84 => 48,  82 => 47,  59 => 27,  55 => 26,  31 => 4,  28 => 3,  11 => 1,);
    }
}
/* {% extends 'master.twig' %}*/
/* */
/* {% block body %}*/
/* <style type="text/css">*/
/*   body {*/
/*     background-color: #DADADA;*/
/*   }*/
/*   body > .grid {*/
/*     height: 100%;*/
/*   }*/
/*   .image {*/
/*     margin-top: -100px;*/
/*   }*/
/*   .column {*/
/*     max-width: 450px;*/
/*   }*/
/* </style>*/
/* <div class="ui middle aligned center aligned grid">*/
/*   <div class="column">*/
/*     <h2 class="ui teal image header">*/
/*       <img src="assets/images/logo.png" class="image">*/
/*       <div class="content">*/
/*         Acesse sua conta*/
/*       </div>*/
/*     </h2>*/
/*     <form class="ui large form" method="post" action="{{baseUrl()}}/login" >*/
/*       <input type="hidden" name="redirect" value="{{ flash.redirect ? : redirect}}">*/
/*       <div class="ui stacked segment">*/
/*         <div class="field">*/
/*           <div class="ui left icon input">*/
/*             <i class="user icon"></i>*/
/*             <input type="text" name="email" placeholder="E-mail">*/
/*           </div>*/
/*         </div>*/
/*         <div class="field">*/
/*           <div class="ui left icon input">*/
/*             <i class="lock icon"></i>*/
/*             <input type="password" name="password" placeholder="Senha">*/
/*           </div>*/
/*         </div>*/
/*         <div class="ui fluid large teal submit button">Login</div>*/
/*       </div>*/
/* */
/*       <div class="ui error message"></div>*/
/* */
/*     </form>*/
/*     {% if flash.message %}*/
/*     <div class="ui warning message " style="margin-top: 25px">*/
/*         <i class="close icon"></i>*/
/*         <p>*/
/*           {{ flash.message }}*/
/*         </p>*/
/*     </div>*/
/*     {% endif %}*/
/*     <input name="remember" type="checkbox" value="Remember Me" {% if flash.remember %}checked{% endif %}>Remember Me*/
/*     <div class="ui message">*/
/*       Esqueceu a senha ? <a href="/resetpass">Clique aqui</a>*/
/*     </div>*/
/*   </div>*/
/* </div>*/
/* */
/* {% endblock %}*/
/* */
