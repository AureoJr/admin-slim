<?php

/* docs/index.twig */
class __TwigTemplate_96c01c5ed3ab323ca3324c77e50f51f5170a9940263504d92844a023fdba6162 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("master.twig", "docs/index.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "master.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        // line 4
        echo "    <div id=\"wrapper\">
        ";
        // line 5
        echo twig_include($this->env, $context, "docs/topbar.twig");
        echo "
        ";
        // line 6
        echo twig_include($this->env, $context, "docs/sidebar.twig");
        echo "
        <div id=\"page-wrapper\" style=\"margin-top:50px\">
            <div class=\"row\">
                <div class=\"col-lg-12\">
                    <h3 class=\"page-header\">";
        // line 10
        echo twig_escape_filter($this->env, (isset($context["title"]) ? $context["title"] : null), "html", null, true);
        echo "</h3>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->
";
    }

    public function getTemplateName()
    {
        return "docs/index.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  45 => 10,  38 => 6,  34 => 5,  31 => 4,  28 => 3,  11 => 1,);
    }
}
/* {% extends 'master.twig' %}*/
/* */
/* {% block body %}*/
/*     <div id="wrapper">*/
/*         {{include('docs/topbar.twig')}}*/
/*         {{include('docs/sidebar.twig')}}*/
/*         <div id="page-wrapper" style="margin-top:50px">*/
/*             <div class="row">*/
/*                 <div class="col-lg-12">*/
/*                     <h3 class="page-header">{{ title }}</h3>*/
/*                 </div>*/
/*                 <!-- /.col-lg-12 -->*/
/*             </div>*/
/*             <!-- /.row -->*/
/*         </div>*/
/*         <!-- /#page-wrapper -->*/
/* */
/*     </div>*/
/*     <!-- /#wrapper -->*/
/* {% endblock %}*/
