<?php

/* docs/sidebar.twig */
class __TwigTemplate_dc4033b5ab633d3db81c11335042bc22e7301073f3113c072b3328b0354a2f60 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<nav class=\"navbar-default navbar-static-side\" role=\"navigation\">
    <div class=\"sidebar-collapse\">
        <ul class=\"nav\" id=\"side-menu\">
            <li>
                <a href=\"";
        // line 5
        echo twig_escape_filter($this->env, $this->env->getExtension('slim')->site("/"), "html", null, true);
        echo "\"><i class=\"fa fa-home fa-fw\"></i> Index</a>
            </li>
        </ul>
        <!-- /#side-menu -->
    </div>
    <!-- /.sidebar-collapse -->
</nav>
<!-- /.navbar-static-side -->";
    }

    public function getTemplateName()
    {
        return "docs/sidebar.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 5,  19 => 1,);
    }
}
/* <nav class="navbar-default navbar-static-side" role="navigation">*/
/*     <div class="sidebar-collapse">*/
/*         <ul class="nav" id="side-menu">*/
/*             <li>*/
/*                 <a href="{{siteUrl('/')}}"><i class="fa fa-home fa-fw"></i> Index</a>*/
/*             </li>*/
/*         </ul>*/
/*         <!-- /#side-menu -->*/
/*     </div>*/
/*     <!-- /.sidebar-collapse -->*/
/* </nav>*/
/* <!-- /.navbar-static-side -->*/
