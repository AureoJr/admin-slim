<?php

/* admin/dashboard.twig */
class __TwigTemplate_ffbe7d86f0d6d18f8258c3c0b85014e061ea253f1869c9b579da6e82534a9165 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<div class=\"ui container\" style=\"margin-top: 80px\">
  <div class=\"ui grid\">
    <div class=\"wide column\">
      <div class=\"ui feed\">
        <div class=\"event\">
          <div class=\"label\">
            <img src=\"/assets/images/img1.png\">
          </div>
          <div class=\"content\">
            <div class=\"summary\">
              <a class=\"user\">
                Aureo Junior
              </a> Acabou de responder o chamado #4356
              <div class=\"date\">
                Há 1 hora
              </div>
            </div>
            <div class=\"meta\">
              <a class=\"like\">
                <i class=\"like icon\"></i> 4 Likes
              </a>
            </div>
          </div>
        </div>
        <div class=\"event\">
          <div class=\"label\">
            <img src=\"/assets/images/img1.png\">
          </div>
          <div class=\"content\">
            <div class=\"summary\">
              <a>Helen Troy</a> added <a>2 new illustrations</a>
              <div class=\"date\">
                4 days ago
              </div>
            </div>
            <div class=\"extra images\">
              <a><img src=\"/assets/images/img3.png\"></a>
              <a><img src=\"/assets/images/img2.png\"></a>
            </div>
            <div class=\"meta\">
              <a class=\"like\">
                <i class=\"like icon\"></i> 1 Like
              </a>
            </div>
          </div>
        </div>
        <div class=\"event\">
          <div class=\"label\">
            <img src=\"/assets/images/img1.png\">
          </div>
          <div class=\"content\">
            <div class=\"summary\">
              <a class=\"user\">
                Jenny Hess
              </a> added you as a friend
              <div class=\"date\">
                2 Days Ago
              </div>
            </div>
            <div class=\"meta\">
              <a class=\"like\">
                <i class=\"like icon\"></i> 8 Likes
              </a>
            </div>
          </div>
        </div>
        <div class=\"event\">
          <div class=\"label\">
            <img src=\"/assets/images/img4.png\">
          </div>
          <div class=\"content\">
            <div class=\"summary\">
              <a>Joe Henderson</a> posted on his page
              <div class=\"date\">
                3 days ago
              </div>
            </div>
            <div class=\"extra text\">
              Ours is a life of constant reruns. We're always circling back to where we'd we started, then starting all over again. Even if we don't run extra laps that day, we surely will come back for more of the same another day soon.
            </div>
            <div class=\"meta\">
              <a class=\"like\">
                <i class=\"like icon\"></i> 5 Likes
              </a>
            </div>
          </div>
        </div>
        <div class=\"event\">
          <div class=\"label\">
            <img src=\"/assets/images/img4.png\">
          </div>
          <div class=\"content\">
            <div class=\"summary\">
              <a>Justen Kitsune</a> added <a>2 new photos</a> of you
              <div class=\"date\">
                4 days ago
              </div>
            </div>
            <div class=\"extra images\">
              <a><img src=\"/assets/images/img1.png\"></a>
              <a><img src=\"/assets/images/img1.png\"></a>
            </div>
            <div class=\"meta\">
              <a class=\"like\">
                <i class=\"like icon\"></i> 41 Likes
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
";
    }

    public function getTemplateName()
    {
        return "admin/dashboard.twig";
    }

    public function getDebugInfo()
    {
        return array (  19 => 1,);
    }
}
/* <div class="ui container" style="margin-top: 80px">*/
/*   <div class="ui grid">*/
/*     <div class="wide column">*/
/*       <div class="ui feed">*/
/*         <div class="event">*/
/*           <div class="label">*/
/*             <img src="/assets/images/img1.png">*/
/*           </div>*/
/*           <div class="content">*/
/*             <div class="summary">*/
/*               <a class="user">*/
/*                 Aureo Junior*/
/*               </a> Acabou de responder o chamado #4356*/
/*               <div class="date">*/
/*                 Há 1 hora*/
/*               </div>*/
/*             </div>*/
/*             <div class="meta">*/
/*               <a class="like">*/
/*                 <i class="like icon"></i> 4 Likes*/
/*               </a>*/
/*             </div>*/
/*           </div>*/
/*         </div>*/
/*         <div class="event">*/
/*           <div class="label">*/
/*             <img src="/assets/images/img1.png">*/
/*           </div>*/
/*           <div class="content">*/
/*             <div class="summary">*/
/*               <a>Helen Troy</a> added <a>2 new illustrations</a>*/
/*               <div class="date">*/
/*                 4 days ago*/
/*               </div>*/
/*             </div>*/
/*             <div class="extra images">*/
/*               <a><img src="/assets/images/img3.png"></a>*/
/*               <a><img src="/assets/images/img2.png"></a>*/
/*             </div>*/
/*             <div class="meta">*/
/*               <a class="like">*/
/*                 <i class="like icon"></i> 1 Like*/
/*               </a>*/
/*             </div>*/
/*           </div>*/
/*         </div>*/
/*         <div class="event">*/
/*           <div class="label">*/
/*             <img src="/assets/images/img1.png">*/
/*           </div>*/
/*           <div class="content">*/
/*             <div class="summary">*/
/*               <a class="user">*/
/*                 Jenny Hess*/
/*               </a> added you as a friend*/
/*               <div class="date">*/
/*                 2 Days Ago*/
/*               </div>*/
/*             </div>*/
/*             <div class="meta">*/
/*               <a class="like">*/
/*                 <i class="like icon"></i> 8 Likes*/
/*               </a>*/
/*             </div>*/
/*           </div>*/
/*         </div>*/
/*         <div class="event">*/
/*           <div class="label">*/
/*             <img src="/assets/images/img4.png">*/
/*           </div>*/
/*           <div class="content">*/
/*             <div class="summary">*/
/*               <a>Joe Henderson</a> posted on his page*/
/*               <div class="date">*/
/*                 3 days ago*/
/*               </div>*/
/*             </div>*/
/*             <div class="extra text">*/
/*               Ours is a life of constant reruns. We're always circling back to where we'd we started, then starting all over again. Even if we don't run extra laps that day, we surely will come back for more of the same another day soon.*/
/*             </div>*/
/*             <div class="meta">*/
/*               <a class="like">*/
/*                 <i class="like icon"></i> 5 Likes*/
/*               </a>*/
/*             </div>*/
/*           </div>*/
/*         </div>*/
/*         <div class="event">*/
/*           <div class="label">*/
/*             <img src="/assets/images/img4.png">*/
/*           </div>*/
/*           <div class="content">*/
/*             <div class="summary">*/
/*               <a>Justen Kitsune</a> added <a>2 new photos</a> of you*/
/*               <div class="date">*/
/*                 4 days ago*/
/*               </div>*/
/*             </div>*/
/*             <div class="extra images">*/
/*               <a><img src="/assets/images/img1.png"></a>*/
/*               <a><img src="/assets/images/img1.png"></a>*/
/*             </div>*/
/*             <div class="meta">*/
/*               <a class="like">*/
/*                 <i class="like icon"></i> 41 Likes*/
/*               </a>*/
/*             </div>*/
/*           </div>*/
/*         </div>*/
/*       </div>*/
/*     </div>*/
/*   </div>*/
/* </div>*/
/* */
