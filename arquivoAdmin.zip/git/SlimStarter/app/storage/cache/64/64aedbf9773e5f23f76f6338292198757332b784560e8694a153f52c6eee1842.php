<?php

/* admin/sidebar.twig */
class __TwigTemplate_ad05b9c7241e51a8d500e3f80cf0b829b53ac826819eab9a74ea2a98634d0be5 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<style>
.ui.inverted.menu .item, .ui.inverted.menu .item>a:not(.ui) {
    background: 0 0;
    color: #333 !important;
    color: rgba(255,255,255,.9);
  }
  .ui.inverted.menu {
      border: 0 solid transparent;
      background: #9A9DA0;
      box-shadow: none;
      color: #A99C9C;
  }
</style>

<div class=\"ui sidebar inverted vertical menu visible\" style=\"padding-top: 65px; z-index : 0\">
  <a class=\"item\" href=\"/admin\">
    <i class=\"home icon active\"></i>
    Dashboard
  </a>
  <a class=\"item\" href=\"/admin/user\">
    <i class=\"users layout icon\"></i>
    Usuarios
  </a>
  <a class=\"item\">
    <i class=\"users layout icon\"></i>
    Silos
  </a>
  <a class=\"item\">
    <i class=\"help icon\"></i>
    Ajuda
  </a>
</div>
";
    }

    public function getTemplateName()
    {
        return "admin/sidebar.twig";
    }

    public function getDebugInfo()
    {
        return array (  19 => 1,);
    }
}
/* <style>*/
/* .ui.inverted.menu .item, .ui.inverted.menu .item>a:not(.ui) {*/
/*     background: 0 0;*/
/*     color: #333 !important;*/
/*     color: rgba(255,255,255,.9);*/
/*   }*/
/*   .ui.inverted.menu {*/
/*       border: 0 solid transparent;*/
/*       background: #9A9DA0;*/
/*       box-shadow: none;*/
/*       color: #A99C9C;*/
/*   }*/
/* </style>*/
/* */
/* <div class="ui sidebar inverted vertical menu visible" style="padding-top: 65px; z-index : 0">*/
/*   <a class="item" href="/admin">*/
/*     <i class="home icon active"></i>*/
/*     Dashboard*/
/*   </a>*/
/*   <a class="item" href="/admin/user">*/
/*     <i class="users layout icon"></i>*/
/*     Usuarios*/
/*   </a>*/
/*   <a class="item">*/
/*     <i class="users layout icon"></i>*/
/*     Silos*/
/*   </a>*/
/*   <a class="item">*/
/*     <i class="help icon"></i>*/
/*     Ajuda*/
/*   </a>*/
/* </div>*/
/* */
