<?php

/* admin/index.twig */
class __TwigTemplate_33a374e56d9c4b50c9baab2215b06fab6b32b4d5251864695602e86d33941191 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("default.twig", "admin/index.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "default.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        // line 4
        echo "
            ";
        // line 5
        $this->displayBlock('content', $context, $blocks);
        // line 8
        echo "
";
    }

    // line 5
    public function block_content($context, array $blocks = array())
    {
        // line 6
        echo "                ";
        $this->loadTemplate("admin/dashboard.twig", "admin/index.twig", 6)->display($context);
        // line 7
        echo "            ";
    }

    public function getTemplateName()
    {
        return "admin/index.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  48 => 7,  45 => 6,  42 => 5,  37 => 8,  35 => 5,  32 => 4,  29 => 3,  11 => 1,);
    }
}
/* {% extends 'default.twig' %}*/
/* */
/* {% block body %}*/
/* */
/*             {% block content %}*/
/*                 {% include 'admin/dashboard.twig' %}*/
/*             {% endblock %}*/
/* */
/* {% endblock %}*/
/* */
