<?php

/* admin/topbar.twig */
class __TwigTemplate_3f935c4f25d1d84c3fc6fd6570b4eead56f6a238a055fd9ebaf95d00a5a94251 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "
 <style type=\"text/css\">

 body {
   background-color: #FFFFFF;
 }
 .main.container {
   margin-top: 2em;
 }
 .main.menu .item img.logo {
   margin-right: 1.5em;
 }

 .overlay {
   float: left;
   margin: 0em 3em 1em 0em;
 }
 .overlay .menu {
   position: relative;
   left: 0;
   transition: left 0.5s ease;
 }

 .main.menu.fixed {
    background-color: #FFFFFF;
    border: 1px solid #DDD;
    box-shadow: 0px 3px 5px rgba(0, 0, 0, 0.2);
    position:  fixed;
    top: 0px;
    left: auto;
    z-index: 1;
 }
 .overlay.fixed .menu {
   left: 800px;
 }
 .ui.text.container{
   justify-content: center;;
    
 }
 .text.container .left.floated.image {
   margin: 2em 2em 2em -4em;
 }
 .text.container .right.floated.image {
   margin: 2em -4em 2em 2em;
 }

 .ui.footer.segment {
   margin: 5em 0em 0em;
   padding: 5em 0em;
 }

 </style>

<div class=\"ui borderless main menu fixed\">
  <div class=\"ui text container\">
    <div href=\"#\" class=\"header item\">
      <img class=\"logo\" src=\"assets/images/logo.png\">
      Dashboard
    </div>
  </div>
</div>
";
    }

    public function getTemplateName()
    {
        return "admin/topbar.twig";
    }

    public function getDebugInfo()
    {
        return array (  19 => 1,);
    }
}
/* */
/*  <style type="text/css">*/
/* */
/*  body {*/
/*    background-color: #FFFFFF;*/
/*  }*/
/*  .main.container {*/
/*    margin-top: 2em;*/
/*  }*/
/*  .main.menu .item img.logo {*/
/*    margin-right: 1.5em;*/
/*  }*/
/* */
/*  .overlay {*/
/*    float: left;*/
/*    margin: 0em 3em 1em 0em;*/
/*  }*/
/*  .overlay .menu {*/
/*    position: relative;*/
/*    left: 0;*/
/*    transition: left 0.5s ease;*/
/*  }*/
/* */
/*  .main.menu.fixed {*/
/*     background-color: #FFFFFF;*/
/*     border: 1px solid #DDD;*/
/*     box-shadow: 0px 3px 5px rgba(0, 0, 0, 0.2);*/
/*     position:  fixed;*/
/*     top: 0px;*/
/*     left: auto;*/
/*     z-index: 1;*/
/*  }*/
/*  .overlay.fixed .menu {*/
/*    left: 800px;*/
/*  }*/
/*  .ui.text.container{*/
/*    justify-content: center;;*/
/*     */
/*  }*/
/*  .text.container .left.floated.image {*/
/*    margin: 2em 2em 2em -4em;*/
/*  }*/
/*  .text.container .right.floated.image {*/
/*    margin: 2em -4em 2em 2em;*/
/*  }*/
/* */
/*  .ui.footer.segment {*/
/*    margin: 5em 0em 0em;*/
/*    padding: 5em 0em;*/
/*  }*/
/* */
/*  </style>*/
/* */
/* <div class="ui borderless main menu fixed">*/
/*   <div class="ui text container">*/
/*     <div href="#" class="header item">*/
/*       <img class="logo" src="assets/images/logo.png">*/
/*       Dashboard*/
/*     </div>*/
/*   </div>*/
/* </div>*/
/* */
