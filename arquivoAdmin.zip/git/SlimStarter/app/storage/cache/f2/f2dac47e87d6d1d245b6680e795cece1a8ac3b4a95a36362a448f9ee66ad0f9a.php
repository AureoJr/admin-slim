<?php

/* default.twig */
class __TwigTemplate_0a156353a99b458b5dee58ad62f76f95ac3c981a7f029330e34d41289b60a42f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!DOCTYPE html>
<html>
<head>
    <title>";
        // line 4
        echo twig_escape_filter($this->env, (isset($context["title"]) ? $context["title"] : null), "html", null, true);
        echo "</title>
    <meta charset=\"utf-8\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">

    ";
        // line 8
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["meta"]) ? $context["meta"] : null));
        foreach ($context['_seq'] as $context["metaname"] => $context["metavalue"]) {
            // line 9
            echo "    <meta name=\"";
            echo twig_escape_filter($this->env, $context["metaname"], "html", null, true);
            echo "\" value=\"";
            echo twig_escape_filter($this->env, $context["metavalue"], "html", null, true);
            echo "\" />
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['metaname'], $context['metavalue'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 11
        echo "
    <!-- publish javascript variable -->
    <script>
        var global = ";
        // line 14
        echo twig_jsonencode_filter((isset($context["global"]) ? $context["global"] : null));
        echo "
    </script>

    <!-- Include registered css -->
    ";
        // line 18
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["css"]) ? $context["css"] : null), "external", array()));
        foreach ($context['_seq'] as $context["_key"] => $context["cssfile"]) {
            // line 19
            echo "    <link rel=\"stylesheet\" href=\"";
            echo twig_escape_filter($this->env, $context["cssfile"], "html", null, true);
            echo "\" />
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['cssfile'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 21
        echo "
    ";
        // line 22
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["css"]) ? $context["css"] : null), "internal", array()));
        foreach ($context['_seq'] as $context["_key"] => $context["cssfile"]) {
            // line 23
            echo "    <link rel=\"stylesheet\" href=\"";
            echo twig_escape_filter($this->env, (isset($context["assetUrl"]) ? $context["assetUrl"] : null), "html", null, true);
            echo "css/";
            echo twig_escape_filter($this->env, $context["cssfile"], "html", null, true);
            echo "\" />
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['cssfile'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 25
        echo "</head>
  <body id=\"example\" class=\"message\" ontouchstart=\"\">
    ";
        // line 27
        $this->loadTemplate("admin/sidebar-responsive.twig", "default.twig", 27)->display($context);
        // line 28
        echo "    <div class=\"ui black big launch right attached fixed button\">
      <i class=\"content icon\"></i>
      <span class=\"text\">Menu</span>
    </div>
    <div class=\"ui fixed inverted main menu\">
      <div class=\"ui container\">
        <a class=\"launch icon item\">
        <i class=\"content icon\"></i>
        </a>
        <div class=\"right menu\">
          <div class=\"vertically fitted borderless item\">
            <i class=\"sing icon\"></i>
          </div>
        </div>
      </div>
    </div>
    <div class=\"pusher\">
      <div class=\"full height\">
        <div class=\"toc\">
          ";
        // line 47
        $this->loadTemplate("admin/sidebar.twig", "default.twig", 47)->display($context);
        // line 48
        echo "        </div>
        <div class=\"article\">
          <link rel=\"stylesheet/less\" type=\"text/css\" href=\"/src/definitions/collections/message.less\" />
          <script src=\"/javascript/message.js\"></script>
          <div class=\"ui masthead vertical segment\">
            <div class=\"ui container\">
              <div class=\"introduction\">
                <h1 class=\"ui header\">
                  Dashboard
                  <div class=\"sub header\">
                    Confira as ultimas informações
                  </div>
                </h1>
              </div>
            </div>
          </div>
          <div class=\"ui main container\">
            ";
        // line 65
        $this->displayBlock('body', $context, $blocks);
        // line 66
        echo "          </div>
        </div>
      </div>
      <div class=\"ui black inverted vertical footer segment\">
        <div class=\"ui center aligned container\">
          <img src=\"/assets/images/logo.png\" class=\"ui centered mini image\">
          <div class=\"ui horizontal inverted small divided link list\">
            <a class=\"item\" href=\"https://facebook.com/aureoju\" target=\"_blank\">/Aureoju</a>
          </div>
        </div>
      </div>
    </div>

  </body>
</html>
";
    }

    // line 65
    public function block_body($context, array $blocks = array())
    {
    }

    public function getTemplateName()
    {
        return "default.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  159 => 65,  140 => 66,  138 => 65,  119 => 48,  117 => 47,  96 => 28,  94 => 27,  90 => 25,  79 => 23,  75 => 22,  72 => 21,  63 => 19,  59 => 18,  52 => 14,  47 => 11,  36 => 9,  32 => 8,  25 => 4,  20 => 1,);
    }
}
/* <!DOCTYPE html>*/
/* <html>*/
/* <head>*/
/*     <title>{{ title }}</title>*/
/*     <meta charset="utf-8">*/
/*     <meta name="viewport" content="width=device-width, initial-scale=1.0">*/
/* */
/*     {% for metaname, metavalue in meta %}*/
/*     <meta name="{{metaname}}" value="{{metavalue}}" />*/
/*     {% endfor %}*/
/* */
/*     <!-- publish javascript variable -->*/
/*     <script>*/
/*         var global = {{global|json_encode|raw}}*/
/*     </script>*/
/* */
/*     <!-- Include registered css -->*/
/*     {% for cssfile in css.external %}*/
/*     <link rel="stylesheet" href="{{cssfile}}" />*/
/*     {% endfor %}*/
/* */
/*     {% for cssfile in css.internal %}*/
/*     <link rel="stylesheet" href="{{assetUrl}}css/{{cssfile}}" />*/
/*     {% endfor %}*/
/* </head>*/
/*   <body id="example" class="message" ontouchstart="">*/
/*     {% include('admin/sidebar-responsive.twig') %}*/
/*     <div class="ui black big launch right attached fixed button">*/
/*       <i class="content icon"></i>*/
/*       <span class="text">Menu</span>*/
/*     </div>*/
/*     <div class="ui fixed inverted main menu">*/
/*       <div class="ui container">*/
/*         <a class="launch icon item">*/
/*         <i class="content icon"></i>*/
/*         </a>*/
/*         <div class="right menu">*/
/*           <div class="vertically fitted borderless item">*/
/*             <i class="sing icon"></i>*/
/*           </div>*/
/*         </div>*/
/*       </div>*/
/*     </div>*/
/*     <div class="pusher">*/
/*       <div class="full height">*/
/*         <div class="toc">*/
/*           {% include('admin/sidebar.twig') %}*/
/*         </div>*/
/*         <div class="article">*/
/*           <link rel="stylesheet/less" type="text/css" href="/src/definitions/collections/message.less" />*/
/*           <script src="/javascript/message.js"></script>*/
/*           <div class="ui masthead vertical segment">*/
/*             <div class="ui container">*/
/*               <div class="introduction">*/
/*                 <h1 class="ui header">*/
/*                   Dashboard*/
/*                   <div class="sub header">*/
/*                     Confira as ultimas informações*/
/*                   </div>*/
/*                 </h1>*/
/*               </div>*/
/*             </div>*/
/*           </div>*/
/*           <div class="ui main container">*/
/*             {% block body %}{% endblock %}*/
/*           </div>*/
/*         </div>*/
/*       </div>*/
/*       <div class="ui black inverted vertical footer segment">*/
/*         <div class="ui center aligned container">*/
/*           <img src="/assets/images/logo.png" class="ui centered mini image">*/
/*           <div class="ui horizontal inverted small divided link list">*/
/*             <a class="item" href="https://facebook.com/aureoju" target="_blank">/Aureoju</a>*/
/*           </div>*/
/*         </div>*/
/*       </div>*/
/*     </div>*/
/* */
/*   </body>*/
/* </html>*/
/* */
