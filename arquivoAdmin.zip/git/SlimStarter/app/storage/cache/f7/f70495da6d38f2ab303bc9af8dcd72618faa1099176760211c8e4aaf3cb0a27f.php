<?php

/* docs/topbar.twig */
class __TwigTemplate_a742bf9a3682340cacee69901223bf17b2e888b62b8a0dd3ff60b7211a20ebdd extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<nav class=\"navbar navbar-default navbar-fixed-top\" role=\"navigation\" style=\"margin-bottom: 0\">
    <div class=\"navbar-header\">
        <button type=\"button\" class=\"navbar-toggle\" data-toggle=\"collapse\" data-target=\".sidebar-collapse\">
            <span class=\"sr-only\">Toggle navigation</span>
            <span class=\"icon-bar\"></span>
            <span class=\"icon-bar\"></span>
            <span class=\"icon-bar\"></span>
        </button>
        <a class=\"navbar-brand\" href=\"";
        // line 9
        echo twig_escape_filter($this->env, $this->env->getExtension('slim')->site("/"), "html", null, true);
        echo "\">Slim Starter Documentation</a>
    </div>
    <!-- /.navbar-header -->

</nav>
<!-- /.navbar-fixed-top -->";
    }

    public function getTemplateName()
    {
        return "docs/topbar.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  29 => 9,  19 => 1,);
    }
}
/* <nav class="navbar navbar-default navbar-fixed-top" role="navigation" style="margin-bottom: 0">*/
/*     <div class="navbar-header">*/
/*         <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">*/
/*             <span class="sr-only">Toggle navigation</span>*/
/*             <span class="icon-bar"></span>*/
/*             <span class="icon-bar"></span>*/
/*             <span class="icon-bar"></span>*/
/*         </button>*/
/*         <a class="navbar-brand" href="{{siteUrl('/')}}">Slim Starter Documentation</a>*/
/*     </div>*/
/*     <!-- /.navbar-header -->*/
/* */
/* </nav>*/
/* <!-- /.navbar-fixed-top -->*/
