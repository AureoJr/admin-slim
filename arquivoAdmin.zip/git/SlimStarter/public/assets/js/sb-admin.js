$(function() {
    $('#side-menu').metisMenu();
    $(document)
      .ready(function() {

        // lazy load images
        $('.image').visibility({
          type: 'image',
          transition: 'vertical flip in',
          duration: 500
        });

        $('.message .close')
          .on('click', function() {
            $(this)
              .closest('.message')
              .transition('fade')
            ;
          })
        ;

        // show dropdown on hover
        $('.main.menu  .ui.dropdown').dropdown({
          on: 'hover'
        });
      });
      $('.ui.form')
        .form({
          fields: {
            email: {
              identifier  : 'email',
              rules: [
                {
                  type   : 'empty',
                  prompt : 'preencha seu email'
                },
                {
                  type   : 'email',
                  prompt : 'E-mail inválido'
                }
              ]
            }
          }
        })
      ;
});

//Loads the correct sidebar on window load,
//collapses the sidebar on window resize.
$(function() {
    $(window).bind("load resize", function() {
        if ($(this).width() < 768) {
            $('div.sidebar-collapse').addClass('collapse');
        } else {
            $('div.sidebar-collapse').removeClass('collapse');
        }

        $('#page-wrapper').css('min-height', $(this).height() - $('.navbar').outerHeight());
    });
});
