<?php
$app = require '../app/bootstrap/start.php';
$app->run();