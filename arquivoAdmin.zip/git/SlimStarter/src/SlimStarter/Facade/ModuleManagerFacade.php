<?php

namespace SlimStarter\Facade;

class ModuleManagerFacade extends \SlimFacades\Facade{
    protected static function getFacadeAccessor() { return 'module'; }
}