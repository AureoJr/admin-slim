<?php

namespace Admin;

use \App;
use \View;
use \Input;
use \Sentry;
use \Response;

class PropertyController extends BaseController
{

    public function index()
    {
        $this->data['title']       = 'Cadastro de propriedade';
        $this->data['description'] = 'Cadastro das propriedades onde são vinculados Silos a propriedade e a seus respectivos donos';
        App::render('admin/property/index.twig', $this->data);
    }
}
