<?php

namespace Admin;

use \App;
use \View;
use \Input;
use \Sentry;
use \Response;

class SuporteController extends BaseController
{

    public function index()
    {
        $this->data['title']       = 'Suporte';
        $this->data['description'] = 'Dúvidas, reclamações ou sugestões ';
        App::render('admin/suporte.twig', $this->data);
    }
}
