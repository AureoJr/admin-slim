<?php

class Group extends Model {}
