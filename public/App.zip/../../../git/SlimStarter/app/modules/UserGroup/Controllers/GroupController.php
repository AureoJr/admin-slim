<?php
namespace UserGroup\Controllers;

use \App;
use \View;
use \Menu;
use \Group;
use \Input;
use \Sentry;
use \Request;
use \Response;
use \Exception;
use \Admin\BaseController;
use \Cartalyst\Sentry\Users\UserNotFoundException;

class GroupController extends BaseController
{

    public function __construct()
    {
        parent::__construct();

    }

    public function index()
    {

        $this->data['title']        = 'Grupos';
        $this->data['description']  = 'Gerenciamento de grupos e acesso ';
        $this->data['groups']       = Group::get()
                                          ->toArray();

        /** load the user.js app */
        $this->loadJs('app/group.js');

        /** publish necessary js  variable */
        $this->publish('baseUrl', $this->data['baseUrl']);

        /** render the template */
        View::display('@usergroup/group/index.twig', $this->data);
    }

    public function show($id)
    {
      if(Request::isAjax()){
          $group = null;
          $message = '';

          try{
              $group = Sentry::findGroupById($id);
          }catch(Exception $e){
              $message = $e->getMessage();
          }


          Response::headers()->set('Content-Type', 'application/json');
          Response::setBody(json_encode(
              array(
                  'success'   => !is_null($group),
                  'data'      => !is_null($group) ? $group->toArray() : $group,
                  'message'   => $message,
                  'code'      => is_null($group) ? 404 : 200
              )
          ));
      }
    }

    public function store()
    {
      $group    = null;
      $message = '';
      $success = false;

      try{
          $input = Input::post();


          $group = Sentry::createGroup(array(
              'name'        => $input['group_name'],
              'description' => $input['group_description'],
              'id_role'     => $input['group_access'],
              'active'   => 1
          ));

          $success = true;
          $message = 'Novo Grupo criado com sucesso';
      }catch (Exception $e){
          $message = $e->getMessage();
      }

      if(Request::isAjax()){
          Response::headers()->set('Content-Type', 'application/json');
          Response::setBody(json_encode(
              array(
                  'success'   => $success,
                  'data'      => ($group) ? $group->toArray() : $group,
                  'message'   => $message,
                  'code'      => $success ? 200 : 500
              )
          ));
      }else{
          Response::redirect($this->siteUrl('admin/group'));
      }

    }

    public function edit($id)
    {
      try{
          $group = Sentry::findGroupById($id);
          //display edit form in non-ajax request
          //
          $this->data['title']        = 'Editar Grupos';
          $this->data['description']  = 'Editar os grupos e acessos';
          $this->data['group']        = $group->toArray();

          View::display('@usergroup/user/edit.twig', $this->data);
      }catch(UserNotFoundException $e){
          App::notFound();
      }catch(Exception $e){
          Response::setBody($e->getMessage());
          Response::finalize();
      }
    }

    public function update($id)
    {
      $success = false;
      $message = '';
      $group   = null;
      $code    = 0;

      try{
          $input = Input::put();
          /** in case request come from post http form */
          $input = is_null($input) ? Input::post() : $input;

          if($input['group_name'] === ''){
              throw new Exception("O grupo criado precisa de um nome", 1);
          }
          if($input['group_access'] === ''){
              $message = "Acesso definido como Cooperando";
          }


          $group = Sentry::findGroupById($id);

          $group->name          = $input['group_name'];
          $group->description   = $input['group_description'];
          $group->id_role       = $input['group_access'];

          $success = $group->save();
          $code    = 200;
          $message = 'Grupo Atualizado';

      }catch(UserNotFoundException $e){
          $message = $e->getMessage();
          $code    = 404;
      }catch (Exception $e){
          $message = $e->getMessage();
          $code    = 500;
      }

      if(Request::isAjax()){
          Response::headers()->set('Content-Type', 'application/json');
          Response::setBody(json_encode(
              array(
                  'success'   => $success,
                  'data'      => ($group) ? $group->toArray() : $group,
                  'message'   => $message,
                  'code'      => $code
              )
          ));
      }else{
          Response::redirect($this->siteUrl('admin/group/'.$id.'/edit'));
      }

    }

    public function destroy($id)
    {
      $id      = (int) $id;
      $deleted = false;
      $message = '';
      $code    = 0;

      try{
          $group   = Sentry::findGroupById($id);
          $deleted = $group->delete();
          $code    = 200;
      }catch(UserNotFoundException $e){
          $message = $e->getMessage();
          $code    = 404;
      }catch(Exception $e){
          $message = $e->getMessage();
          $code    = 500;
      }

      if(Request::isAjax()){
          Response::headers()->set('Content-Type', 'application/json');
          Response::setBody(json_encode(
              array(
                  'success'   => $deleted,
                  'data'      => array( 'id' => $id ),
                  'message'   => $message,
                  'code'      => $code
              )
          ));
      }else{
          Response::redirect($this->siteUrl('admin/user'));
      }
    }
}
