<?php

/* @usergroup/user/index.twig */
class __TwigTemplate_00c877b077f37ae8df2ec134a1f031cbf39b67e106da88ed78952fec9f35180b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("admin/index.twig", "@usergroup/user/index.twig", 1);
        $this->blocks = array(
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "admin/index.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_content($context, array $blocks = array())
    {
        // line 3
        echo "<div class=\"ui grid\">
    <div class=\"sixteen wide column\">
        <h3>";
        // line 5
        echo twig_escape_filter($this->env, (isset($context["title"]) ? $context["title"] : null), "html", null, true);
        echo "</h3>
    </div>
    <div class=\"sixteen wide column\">
      <button  id=\"btn-user-add\" class=\"ui small green right floated button\">
        <i class=\"plus olive icon\"></i>
        Novo Usuário
      </button>
    </div>
</div>
  <div class=\"sixteen wide column\">
    <table class=\"ui compact celled definition table\">
        <thead>
            <tr>
                <th>#</th>
                <th>Nome</th>
                <th>Endereço</th>
                <th>email</th>
                <th  class=\"text-center\">Ações</th>
            </tr>
        </thead>
        <tbody id=\"user-table\">
            ";
        // line 26
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["users"]) ? $context["users"] : null));
        foreach ($context['_seq'] as $context["_key"] => $context["user"]) {
            // line 27
            echo "            <tr id=\"user-row-";
            echo twig_escape_filter($this->env, $this->getAttribute($context["user"], "id", array()), "html", null, true);
            echo "\">
                <td>";
            // line 28
            echo twig_escape_filter($this->env, $this->getAttribute($context["user"], "id", array()), "html", null, true);
            echo "</td>
                <td>";
            // line 29
            echo twig_escape_filter($this->env, $this->getAttribute($context["user"], "first_name", array()), "html", null, true);
            echo "</td>
                <td>";
            // line 30
            echo twig_escape_filter($this->env, $this->getAttribute($context["user"], "last_name", array()), "html", null, true);
            echo "</td>
                <td>";
            // line 31
            echo twig_escape_filter($this->env, $this->getAttribute($context["user"], "email", array()), "html", null, true);
            echo "</td>
                <td class=\"center aligned\">
                   <button data-id=\"";
            // line 33
            echo twig_escape_filter($this->env, $this->getAttribute($context["user"], "id", array()), "html", null, true);
            echo "\"  class=\"ui mini teal button btn-editar\">
                      <i class=\"edit icon\"></i> Editar
                   </button>
                   <button data-id=\"";
            // line 36
            echo twig_escape_filter($this->env, $this->getAttribute($context["user"], "id", array()), "html", null, true);
            echo "\"  class=\"ui mini red  button btn-remover\">
                      <i class=\"remove icon\"></i> Remover
                   </button>
                </td>
            </tr>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['user'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 42
        echo "        </tbody>
    </table>
</div>
<div class=\"ui modal\">
    <i class=\"close icon\"></i>
    <div class=\"header\" id=\"modal-title\">
      Adicionar Usuário
    </div>
    <div class=\"content\">
      ";
        // line 51
        $this->loadTemplate("@usergroup/user/form.twig", "@usergroup/user/index.twig", 51)->display($context);
        // line 52
        echo "    </div>
    <div class=\"actions\">
      <div class=\"ui black deny button\">
        Cancelar
      </div>
      <div id=\"btn-user-save\" class=\"ui positive right labeled icon button\">
        Cadastrar
        <i class=\"checkmark icon\"></i>
      </div>
    </div>
  </div>
</div>
";
    }

    public function getTemplateName()
    {
        return "@usergroup/user/index.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  116 => 52,  114 => 51,  103 => 42,  91 => 36,  85 => 33,  80 => 31,  76 => 30,  72 => 29,  68 => 28,  63 => 27,  59 => 26,  35 => 5,  31 => 3,  28 => 2,  11 => 1,);
    }
}
/* {% extends 'admin/index.twig' %}*/
/* {% block content %}*/
/* <div class="ui grid">*/
/*     <div class="sixteen wide column">*/
/*         <h3>{{ title }}</h3>*/
/*     </div>*/
/*     <div class="sixteen wide column">*/
/*       <button  id="btn-user-add" class="ui small green right floated button">*/
/*         <i class="plus olive icon"></i>*/
/*         Novo Usuário*/
/*       </button>*/
/*     </div>*/
/* </div>*/
/*   <div class="sixteen wide column">*/
/*     <table class="ui compact celled definition table">*/
/*         <thead>*/
/*             <tr>*/
/*                 <th>#</th>*/
/*                 <th>Nome</th>*/
/*                 <th>Endereço</th>*/
/*                 <th>email</th>*/
/*                 <th  class="text-center">Ações</th>*/
/*             </tr>*/
/*         </thead>*/
/*         <tbody id="user-table">*/
/*             {% for user in users %}*/
/*             <tr id="user-row-{{ user.id }}">*/
/*                 <td>{{ user.id }}</td>*/
/*                 <td>{{ user.first_name }}</td>*/
/*                 <td>{{ user.last_name }}</td>*/
/*                 <td>{{ user.email }}</td>*/
/*                 <td class="center aligned">*/
/*                    <button data-id="{{user.id}}"  class="ui mini teal button btn-editar">*/
/*                       <i class="edit icon"></i> Editar*/
/*                    </button>*/
/*                    <button data-id="{{user.id}}"  class="ui mini red  button btn-remover">*/
/*                       <i class="remove icon"></i> Remover*/
/*                    </button>*/
/*                 </td>*/
/*             </tr>*/
/*             {% endfor %}*/
/*         </tbody>*/
/*     </table>*/
/* </div>*/
/* <div class="ui modal">*/
/*     <i class="close icon"></i>*/
/*     <div class="header" id="modal-title">*/
/*       Adicionar Usuário*/
/*     </div>*/
/*     <div class="content">*/
/*       {% include '@usergroup/user/form.twig' %}*/
/*     </div>*/
/*     <div class="actions">*/
/*       <div class="ui black deny button">*/
/*         Cancelar*/
/*       </div>*/
/*       <div id="btn-user-save" class="ui positive right labeled icon button">*/
/*         Cadastrar*/
/*         <i class="checkmark icon"></i>*/
/*       </div>*/
/*     </div>*/
/*   </div>*/
/* </div>*/
/* {% endblock %}*/
/* */
