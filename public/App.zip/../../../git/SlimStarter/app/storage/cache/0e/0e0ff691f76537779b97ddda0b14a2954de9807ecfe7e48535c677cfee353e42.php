<?php

/* @usergroup/group/index.twig */
class __TwigTemplate_24140b4ce09b9c004f3cdae631275d7240d8f34fa639b6234a9ae5ef2b033317 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("admin/index.twig", "@usergroup/group/index.twig", 1);
        $this->blocks = array(
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "admin/index.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_content($context, array $blocks = array())
    {
        // line 3
        echo "<div class=\"ui grid\">
    <div class=\"sixteen wide column\">
        <h3>";
        // line 5
        echo twig_escape_filter($this->env, (isset($context["title"]) ? $context["title"] : null), "html", null, true);
        echo "</h3>
    </div>
    <div class=\"sixteen wide column\">
      <button  id=\"btn-group-add\" class=\"ui small green right floated button\">
        <i class=\"plus olive icon\"></i>
        Novo Grupo
      </button>
    </div>
</div>
  <div class=\"sixteen wide column\">
    <table class=\"ui compact celled definition table\">
        <thead>
            <tr>
                <th>#</th>
                <th>Nome</th>
                <th>Descrição</th>
                <th>Data de criação </th>
                <th  class=\"text-center\">Ações</th>
            </tr>
        </thead>
        <tbody id=\"group-table\">
            ";
        // line 26
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["groups"]) ? $context["groups"] : null));
        foreach ($context['_seq'] as $context["_key"] => $context["group"]) {
            // line 27
            echo "            <tr id=\"group-row-";
            echo twig_escape_filter($this->env, $this->getAttribute($context["group"], "id", array()), "html", null, true);
            echo "\">
                <td>";
            // line 28
            echo twig_escape_filter($this->env, $this->getAttribute($context["group"], "id", array()), "html", null, true);
            echo "</td>
                <td>";
            // line 29
            echo twig_escape_filter($this->env, $this->getAttribute($context["group"], "name", array()), "html", null, true);
            echo "</td>
                <td class=\"text-overflow\">";
            // line 30
            echo twig_escape_filter($this->env, $this->getAttribute($context["group"], "description", array()), "html", null, true);
            echo "</td>
                <td>";
            // line 31
            echo twig_escape_filter($this->env, $this->getAttribute($context["group"], "created_at", array()), "html", null, true);
            echo "</td>
                <td class=\"center aligned\">
                   <button data-id=\"";
            // line 33
            echo twig_escape_filter($this->env, $this->getAttribute($context["group"], "id", array()), "html", null, true);
            echo "\"  class=\"ui mini teal button btn-editar\">
                      <i class=\"edit icon\"></i> Editar
                   </button>
                   <button data-id=\"";
            // line 36
            echo twig_escape_filter($this->env, $this->getAttribute($context["group"], "id", array()), "html", null, true);
            echo "\"  class=\"ui mini red  button btn-remover\">
                      <i class=\"remove icon\"></i> Remover
                   </button>
                </td>
            </tr>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['group'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 42
        echo "        </tbody>
    </table>
</div>
<div class=\"ui modal\">
    <i class=\"close icon\"></i>
    <div class=\"header\" id=\"modal-title\">
      Adicionar Novo Grupo
    </div>
    <div class=\"content\">
      ";
        // line 51
        $this->loadTemplate("@usergroup/group/form.twig", "@usergroup/group/index.twig", 51)->display($context);
        // line 52
        echo "    </div>
    <div class=\"actions\">
      <div class=\"ui black deny button\">
        Cancelar
      </div>
      <div id=\"btn-group-save\" class=\"ui positive right labeled icon button\">
        Cadastrar
        <i class=\"checkmark icon\"></i>
      </div>
    </div>
  </div>
</div>
";
    }

    public function getTemplateName()
    {
        return "@usergroup/group/index.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  116 => 52,  114 => 51,  103 => 42,  91 => 36,  85 => 33,  80 => 31,  76 => 30,  72 => 29,  68 => 28,  63 => 27,  59 => 26,  35 => 5,  31 => 3,  28 => 2,  11 => 1,);
    }
}
/* {% extends 'admin/index.twig' %}*/
/* {% block content %}*/
/* <div class="ui grid">*/
/*     <div class="sixteen wide column">*/
/*         <h3>{{ title }}</h3>*/
/*     </div>*/
/*     <div class="sixteen wide column">*/
/*       <button  id="btn-group-add" class="ui small green right floated button">*/
/*         <i class="plus olive icon"></i>*/
/*         Novo Grupo*/
/*       </button>*/
/*     </div>*/
/* </div>*/
/*   <div class="sixteen wide column">*/
/*     <table class="ui compact celled definition table">*/
/*         <thead>*/
/*             <tr>*/
/*                 <th>#</th>*/
/*                 <th>Nome</th>*/
/*                 <th>Descrição</th>*/
/*                 <th>Data de criação </th>*/
/*                 <th  class="text-center">Ações</th>*/
/*             </tr>*/
/*         </thead>*/
/*         <tbody id="group-table">*/
/*             {% for group in groups %}*/
/*             <tr id="group-row-{{ group.id }}">*/
/*                 <td>{{ group.id }}</td>*/
/*                 <td>{{ group.name }}</td>*/
/*                 <td class="text-overflow">{{ group.description }}</td>*/
/*                 <td>{{ group.created_at }}</td>*/
/*                 <td class="center aligned">*/
/*                    <button data-id="{{group.id}}"  class="ui mini teal button btn-editar">*/
/*                       <i class="edit icon"></i> Editar*/
/*                    </button>*/
/*                    <button data-id="{{group.id}}"  class="ui mini red  button btn-remover">*/
/*                       <i class="remove icon"></i> Remover*/
/*                    </button>*/
/*                 </td>*/
/*             </tr>*/
/*             {% endfor %}*/
/*         </tbody>*/
/*     </table>*/
/* </div>*/
/* <div class="ui modal">*/
/*     <i class="close icon"></i>*/
/*     <div class="header" id="modal-title">*/
/*       Adicionar Novo Grupo*/
/*     </div>*/
/*     <div class="content">*/
/*       {% include '@usergroup/group/form.twig' %}*/
/*     </div>*/
/*     <div class="actions">*/
/*       <div class="ui black deny button">*/
/*         Cancelar*/
/*       </div>*/
/*       <div id="btn-group-save" class="ui positive right labeled icon button">*/
/*         Cadastrar*/
/*         <i class="checkmark icon"></i>*/
/*       </div>*/
/*     </div>*/
/*   </div>*/
/* </div>*/
/* {% endblock %}*/
/* */
