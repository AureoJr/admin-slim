<?php

/* admin/property/index.twig */
class __TwigTemplate_8e915faf9956231779706471bd046a347defea49cdcfa182458efbffd031017b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("admin/index.twig", "admin/property/index.twig", 1);
        $this->blocks = array(
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "admin/index.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_content($context, array $blocks = array())
    {
        // line 3
        echo "<div class=\"ui grid\">
    <div class=\"sixteen wide column\">
      <button  id=\"btn-property-add\" class=\"ui small green right floated button\">
        <i class=\"plus olive icon\"></i>
        Nova Propriedade
      </button>
      <button  id=\"btn-silo-add\" class=\"ui small green right floated button\">
        <i class=\"plus olive icon\"></i>
        Novo Silo
      </button>
    </div>
</div>
  <div class=\"sixteen wide column\">
    <table class=\"ui compact celled definition table\">
        <thead>
            <tr>
                <th>#</th>
                <th>Nome</th>
                <th>Endereço</th>
                <th>QTD Silos</th>
                <th  class=\"text-center\">Ações</th>
            </tr>
        </thead>
        <tbody id=\"property-table\">
            ";
        // line 27
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["properties"]) ? $context["properties"] : null));
        foreach ($context['_seq'] as $context["_key"] => $context["property"]) {
            // line 28
            echo "            <tr id=\"property-row-";
            echo twig_escape_filter($this->env, $this->getAttribute($context["property"], "id", array()), "html", null, true);
            echo "\">
                <td>";
            // line 29
            echo twig_escape_filter($this->env, $this->getAttribute($context["property"], "id", array()), "html", null, true);
            echo "</td>
                <td>";
            // line 30
            echo twig_escape_filter($this->env, $this->getAttribute($context["property"], "first_name", array()), "html", null, true);
            echo "</td>
                <td>";
            // line 31
            echo twig_escape_filter($this->env, $this->getAttribute($context["property"], "last_name", array()), "html", null, true);
            echo "</td>
                <td>";
            // line 32
            echo twig_escape_filter($this->env, $this->getAttribute($context["property"], "email", array()), "html", null, true);
            echo "</td>
                <td class=\"center aligned\">
                   <button data-id=\"";
            // line 34
            echo twig_escape_filter($this->env, $this->getAttribute($context["property"], "id", array()), "html", null, true);
            echo "\"  class=\"ui mini teal button btn-editar\">
                      <i class=\"edit icon\"></i> Editar
                   </button>
                   <button data-id=\"";
            // line 37
            echo twig_escape_filter($this->env, $this->getAttribute($context["property"], "id", array()), "html", null, true);
            echo "\"  class=\"ui mini red  button btn-remover\">
                      <i class=\"remove icon\"></i> Remover
                   </button>
                </td>
            </tr>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['property'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 43
        echo "        </tbody>
    </table>
</div>
<div class=\"ui modal\">
    <i class=\"close icon\"></i>
    <div class=\"header\" id=\"modal-title\">
      Adicionar Usuário
    </div>
    <div class=\"content\">
      ";
        // line 52
        $this->loadTemplate("admin/property/form/formProperty.twig", "admin/property/index.twig", 52)->display($context);
        // line 53
        echo "    </div>
    <div class=\"actions\">
      <div class=\"ui black deny button\">
        Cancelar
      </div>
      <div id=\"btn-property-save\" class=\"ui positive right labeled icon button\">
        Cadastrar
        <i class=\"checkmark icon\"></i>
      </div>
    </div>
  </div>
</div>
";
    }

    public function getTemplateName()
    {
        return "admin/property/index.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  114 => 53,  112 => 52,  101 => 43,  89 => 37,  83 => 34,  78 => 32,  74 => 31,  70 => 30,  66 => 29,  61 => 28,  57 => 27,  31 => 3,  28 => 2,  11 => 1,);
    }
}
/* {% extends 'admin/index.twig' %}*/
/* {% block content %}*/
/* <div class="ui grid">*/
/*     <div class="sixteen wide column">*/
/*       <button  id="btn-property-add" class="ui small green right floated button">*/
/*         <i class="plus olive icon"></i>*/
/*         Nova Propriedade*/
/*       </button>*/
/*       <button  id="btn-silo-add" class="ui small green right floated button">*/
/*         <i class="plus olive icon"></i>*/
/*         Novo Silo*/
/*       </button>*/
/*     </div>*/
/* </div>*/
/*   <div class="sixteen wide column">*/
/*     <table class="ui compact celled definition table">*/
/*         <thead>*/
/*             <tr>*/
/*                 <th>#</th>*/
/*                 <th>Nome</th>*/
/*                 <th>Endereço</th>*/
/*                 <th>QTD Silos</th>*/
/*                 <th  class="text-center">Ações</th>*/
/*             </tr>*/
/*         </thead>*/
/*         <tbody id="property-table">*/
/*             {% for property in properties %}*/
/*             <tr id="property-row-{{ property.id }}">*/
/*                 <td>{{ property.id }}</td>*/
/*                 <td>{{ property.first_name }}</td>*/
/*                 <td>{{ property.last_name }}</td>*/
/*                 <td>{{ property.email }}</td>*/
/*                 <td class="center aligned">*/
/*                    <button data-id="{{property.id}}"  class="ui mini teal button btn-editar">*/
/*                       <i class="edit icon"></i> Editar*/
/*                    </button>*/
/*                    <button data-id="{{property.id}}"  class="ui mini red  button btn-remover">*/
/*                       <i class="remove icon"></i> Remover*/
/*                    </button>*/
/*                 </td>*/
/*             </tr>*/
/*             {% endfor %}*/
/*         </tbody>*/
/*     </table>*/
/* </div>*/
/* <div class="ui modal">*/
/*     <i class="close icon"></i>*/
/*     <div class="header" id="modal-title">*/
/*       Adicionar Usuário*/
/*     </div>*/
/*     <div class="content">*/
/*       {% include 'admin/property/form/formProperty.twig' %}*/
/*     </div>*/
/*     <div class="actions">*/
/*       <div class="ui black deny button">*/
/*         Cancelar*/
/*       </div>*/
/*       <div id="btn-property-save" class="ui positive right labeled icon button">*/
/*         Cadastrar*/
/*         <i class="checkmark icon"></i>*/
/*       </div>*/
/*     </div>*/
/*   </div>*/
/* </div>*/
/* {% endblock %}*/
/* */
