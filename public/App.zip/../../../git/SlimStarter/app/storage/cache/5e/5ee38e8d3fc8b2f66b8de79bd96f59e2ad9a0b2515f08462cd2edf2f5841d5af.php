<?php

/* admin/dashboard.twig */
class __TwigTemplate_ffbe7d86f0d6d18f8258c3c0b85014e061ea253f1869c9b579da6e82534a9165 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<div class=\"ui container\" style=\"margin-top: 80px\">
  <div >
    <canvas id=\"canvas\"></canvas>
  </div>
  <br>
  <br>
  <button id=\"randomizeData\">Randomize Data</button>
  <button id=\"addDataset\">Add Dataset</button>
  <button id=\"removeDataset\">Remove Dataset</button>
  <button id=\"addData\">Add Data</button>
  <button id=\"removeData\">Remove Data</button>
</div>
";
    }

    public function getTemplateName()
    {
        return "admin/dashboard.twig";
    }

    public function getDebugInfo()
    {
        return array (  19 => 1,);
    }
}
/* <div class="ui container" style="margin-top: 80px">*/
/*   <div >*/
/*     <canvas id="canvas"></canvas>*/
/*   </div>*/
/*   <br>*/
/*   <br>*/
/*   <button id="randomizeData">Randomize Data</button>*/
/*   <button id="addDataset">Add Dataset</button>*/
/*   <button id="removeDataset">Remove Dataset</button>*/
/*   <button id="addData">Add Data</button>*/
/*   <button id="removeData">Remove Data</button>*/
/* </div>*/
/* */
