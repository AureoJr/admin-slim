<?php

/* @usergroup/group/form.twig */
class __TwigTemplate_9aa8a6bb256b98948ed13ed981ffa850907d55a12998b41e86c7eb4d520c00a0 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<form role=\"form\" class=\"ui form\" id=\"group-form-data\">
    <input type=\"hidden\" id=\"group_id\" name=\"id\">
    <input type=\"hidden\" id=\"propriedade_id\" name=\"propriedade_id\">
    <div class=\"field\">
        <label>Nome</label>
        <div class=\"field\">
            <input  name=\"group_name\" id=\"group_name\" placeholder=\" Geral\">
        </div>
    </div>
    <div class=\"field\">
        <label>Descricao</label>
        <div class=\"field\">
            <textarea type=\"text\"  name=\"group_description\" id=\"group_description\" placeholder=\"informações sobre o grupo\"></textarea>
        </div>
    </div>

    <div class=\"field\">
        <label >Nível de acesso</label>
        <div class=\"field\">
          <select class=\"ui fluid dropdown\" name=\"group_access\" id=\"group_id_role\">
            <option value=\"\">Selecione o nível acesso</option>
            <option value=\"1\">Cooperando</option>
            <option value=\"2\">Cooperativa</option>
            <option value=\"3\">Administrador</option>
            <option value=\"4\">Desenvolvedor</option>
          </select>
        </div>
    </div>
</form>
";
    }

    public function getTemplateName()
    {
        return "@usergroup/group/form.twig";
    }

    public function getDebugInfo()
    {
        return array (  19 => 1,);
    }
}
/* <form role="form" class="ui form" id="group-form-data">*/
/*     <input type="hidden" id="group_id" name="id">*/
/*     <input type="hidden" id="propriedade_id" name="propriedade_id">*/
/*     <div class="field">*/
/*         <label>Nome</label>*/
/*         <div class="field">*/
/*             <input  name="group_name" id="group_name" placeholder=" Geral">*/
/*         </div>*/
/*     </div>*/
/*     <div class="field">*/
/*         <label>Descricao</label>*/
/*         <div class="field">*/
/*             <textarea type="text"  name="group_description" id="group_description" placeholder="informações sobre o grupo"></textarea>*/
/*         </div>*/
/*     </div>*/
/* */
/*     <div class="field">*/
/*         <label >Nível de acesso</label>*/
/*         <div class="field">*/
/*           <select class="ui fluid dropdown" name="group_access" id="group_id_role">*/
/*             <option value="">Selecione o nível acesso</option>*/
/*             <option value="1">Cooperando</option>*/
/*             <option value="2">Cooperativa</option>*/
/*             <option value="3">Administrador</option>*/
/*             <option value="4">Desenvolvedor</option>*/
/*           </select>*/
/*         </div>*/
/*     </div>*/
/* </form>*/
/* */
