<?php

/* admin/property/form/formProperty.twig */
class __TwigTemplate_c8c48df2f3401d41464860323d3e94172ea44a7e2fe4d6d8b510d829e812ac95 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<form role=\"form\" class=\"ui form\" id=\"user-form-data\">
    <input type=\"hidden\" id=\"user_id\" name=\"id\">
    <input type=\"hidden\" id=\"propriedade_id\" name=\"propriedade_id\">
    <div class=\"field\">
        <label>Email</label>
        <div class=\"field\">
            <input  name=\"email\" id=\"user_email\" placeholder=\" Ex: seunome@dominio.com\">
        </div>
    </div>

    <div class=\"field\">
        <label >Nome </label>
        <div class=\"field\">
            <input type=\"text\" name=\"first_name\" id=\"user_first_name\" placeholder=\"Ex: Cláudio \">
        </div>
    </div>

    <div class=\"field\">
        <label >Propriedade</label>
        <div class=\"field\">
            <input type=\"text\"  name=\"last_name\" id=\"propriedade\" placeholder=\"Last Name\">
        </div>
    </div>

    <div class=\"field\">
        <label >Nível de acesso</label>
        <div class=\"field\">
          <select class=\"ui fluid dropdown\">
            <option value=\"\">Selecione o nível acesso</option>
            ";
        // line 30
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["groups"]) ? $context["groups"] : null));
        foreach ($context['_seq'] as $context["_key"] => $context["group"]) {
            // line 31
            echo "            <option value=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["group"], "id", array()), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["group"], "name", array()), "html", null, true);
            echo "</option>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['group'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 33
        echo "          </select>
        </div>
    </div>

    <div class=\"two fields\">
      <div class=\"field\">
          <label >Senha</label>
          <input type=\"password\" name=\"password\" id=\"password\" placeholder=\"Senha\">
      </div>

      <div class=\"field\">
          <label >Confirme a senha</label>
          <input type=\"password\" name=\"confirm_password\" id=\"confirm_password\" placeholder=\"Confirme a senha\">
      </div>
    </div>
    <div class=\"ui tiny progress\">
      <div class=\"bar\"></div>
      <div class=\"label\">Força da senha</div>
    </div>
</form>
";
    }

    public function getTemplateName()
    {
        return "admin/property/form/formProperty.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  65 => 33,  54 => 31,  50 => 30,  19 => 1,);
    }
}
/* <form role="form" class="ui form" id="user-form-data">*/
/*     <input type="hidden" id="user_id" name="id">*/
/*     <input type="hidden" id="propriedade_id" name="propriedade_id">*/
/*     <div class="field">*/
/*         <label>Email</label>*/
/*         <div class="field">*/
/*             <input  name="email" id="user_email" placeholder=" Ex: seunome@dominio.com">*/
/*         </div>*/
/*     </div>*/
/* */
/*     <div class="field">*/
/*         <label >Nome </label>*/
/*         <div class="field">*/
/*             <input type="text" name="first_name" id="user_first_name" placeholder="Ex: Cláudio ">*/
/*         </div>*/
/*     </div>*/
/* */
/*     <div class="field">*/
/*         <label >Propriedade</label>*/
/*         <div class="field">*/
/*             <input type="text"  name="last_name" id="propriedade" placeholder="Last Name">*/
/*         </div>*/
/*     </div>*/
/* */
/*     <div class="field">*/
/*         <label >Nível de acesso</label>*/
/*         <div class="field">*/
/*           <select class="ui fluid dropdown">*/
/*             <option value="">Selecione o nível acesso</option>*/
/*             {% for group in groups %}*/
/*             <option value="{{group.id}}">{{group.name}}</option>*/
/*             {% endfor %}*/
/*           </select>*/
/*         </div>*/
/*     </div>*/
/* */
/*     <div class="two fields">*/
/*       <div class="field">*/
/*           <label >Senha</label>*/
/*           <input type="password" name="password" id="password" placeholder="Senha">*/
/*       </div>*/
/* */
/*       <div class="field">*/
/*           <label >Confirme a senha</label>*/
/*           <input type="password" name="confirm_password" id="confirm_password" placeholder="Confirme a senha">*/
/*       </div>*/
/*     </div>*/
/*     <div class="ui tiny progress">*/
/*       <div class="bar"></div>*/
/*       <div class="label">Força da senha</div>*/
/*     </div>*/
/* </form>*/
/* */
