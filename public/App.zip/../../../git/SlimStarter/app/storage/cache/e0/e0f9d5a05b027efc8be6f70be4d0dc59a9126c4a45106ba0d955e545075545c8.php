<?php

/* admin/suporte.twig */
class __TwigTemplate_d10d4e28aadc9cd7ede4868c404a80b395953fe7ab7f5faec479169e989ea327 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("default.twig", "admin/suporte.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "default.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        // line 4
        echo "<div class=\"ui container\" style=\"margin-top: 80px\">
  <div class=\"ui grid\">
    <div class=\"wide column\">
      <div class=\"ui feed\">
        <div class=\"event\">
          <div class=\"label\">
            <img src=\"/assets/images/img1.png\">
          </div>
          <div class=\"content\">
            <div class=\"summary\">
              <a class=\"user\">
                Aureo Junior
              </a> Acabou de responder o chamado #4356
              <div class=\"date\">
                Há 1 hora
              </div>
            </div>
            <div class=\"meta\">
              <a class=\"like\">
                <i class=\"like icon\"></i> 4 Likes
              </a>
            </div>
          </div>
        </div>
        <div class=\"event\">
          <div class=\"label\">
            <img src=\"/assets/images/img1.png\">
          </div>
          <div class=\"content\">
            <div class=\"summary\">
              <a>Helen Troy</a> added <a>2 new illustrations</a>
              <div class=\"date\">
                4 days ago
              </div>
            </div>
            <div class=\"extra images\">
              <a><img src=\"/assets/images/img3.png\"></a>
              <a><img src=\"/assets/images/img2.png\"></a>
            </div>
            <div class=\"meta\">
              <a class=\"like\">
                <i class=\"like icon\"></i> 1 Like
              </a>
            </div>
          </div>
        </div>
        <div class=\"event\">
          <div class=\"label\">
            <img src=\"/assets/images/img1.png\">
          </div>
          <div class=\"content\">
            <div class=\"summary\">
              <a class=\"user\">
                Jenny Hess
              </a> added you as a friend
              <div class=\"date\">
                2 Days Ago
              </div>
            </div>
            <div class=\"meta\">
              <a class=\"like\">
                <i class=\"like icon\"></i> 8 Likes
              </a>
            </div>
          </div>
        </div>
        <div class=\"event\">
          <div class=\"label\">
            <img src=\"/assets/images/img4.png\">
          </div>
          <div class=\"content\">
            <div class=\"summary\">
              <a>Joe Henderson</a> posted on his page
              <div class=\"date\">
                3 days ago
              </div>
            </div>
            <div class=\"extra text\">
              Ours is a life of constant reruns. We're always circling back to where we'd we started, then starting all over again. Even if we don't run extra laps that day, we surely will come back for more of the same another day soon.
            </div>
            <div class=\"meta\">
              <a class=\"like\">
                <i class=\"like icon\"></i> 5 Likes
              </a>
            </div>
          </div>
        </div>
        <div class=\"event\">
          <div class=\"label\">
            <img src=\"/assets/images/img4.png\">
          </div>
          <div class=\"content\">
            <div class=\"summary\">
              <a>Justen Kitsune</a> added <a>2 new photos</a> of you
              <div class=\"date\">
                4 days ago
              </div>
            </div>
            <div class=\"extra images\">
              <a><img src=\"/assets/images/img1.png\"></a>
              <a><img src=\"/assets/images/img1.png\"></a>
            </div>
            <div class=\"meta\">
              <a class=\"like\">
                <i class=\"like icon\"></i> 41 Likes
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
";
    }

    public function getTemplateName()
    {
        return "admin/suporte.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  31 => 4,  28 => 3,  11 => 1,);
    }
}
/* {% extends 'default.twig' %}*/
/* */
/* {% block body %}*/
/* <div class="ui container" style="margin-top: 80px">*/
/*   <div class="ui grid">*/
/*     <div class="wide column">*/
/*       <div class="ui feed">*/
/*         <div class="event">*/
/*           <div class="label">*/
/*             <img src="/assets/images/img1.png">*/
/*           </div>*/
/*           <div class="content">*/
/*             <div class="summary">*/
/*               <a class="user">*/
/*                 Aureo Junior*/
/*               </a> Acabou de responder o chamado #4356*/
/*               <div class="date">*/
/*                 Há 1 hora*/
/*               </div>*/
/*             </div>*/
/*             <div class="meta">*/
/*               <a class="like">*/
/*                 <i class="like icon"></i> 4 Likes*/
/*               </a>*/
/*             </div>*/
/*           </div>*/
/*         </div>*/
/*         <div class="event">*/
/*           <div class="label">*/
/*             <img src="/assets/images/img1.png">*/
/*           </div>*/
/*           <div class="content">*/
/*             <div class="summary">*/
/*               <a>Helen Troy</a> added <a>2 new illustrations</a>*/
/*               <div class="date">*/
/*                 4 days ago*/
/*               </div>*/
/*             </div>*/
/*             <div class="extra images">*/
/*               <a><img src="/assets/images/img3.png"></a>*/
/*               <a><img src="/assets/images/img2.png"></a>*/
/*             </div>*/
/*             <div class="meta">*/
/*               <a class="like">*/
/*                 <i class="like icon"></i> 1 Like*/
/*               </a>*/
/*             </div>*/
/*           </div>*/
/*         </div>*/
/*         <div class="event">*/
/*           <div class="label">*/
/*             <img src="/assets/images/img1.png">*/
/*           </div>*/
/*           <div class="content">*/
/*             <div class="summary">*/
/*               <a class="user">*/
/*                 Jenny Hess*/
/*               </a> added you as a friend*/
/*               <div class="date">*/
/*                 2 Days Ago*/
/*               </div>*/
/*             </div>*/
/*             <div class="meta">*/
/*               <a class="like">*/
/*                 <i class="like icon"></i> 8 Likes*/
/*               </a>*/
/*             </div>*/
/*           </div>*/
/*         </div>*/
/*         <div class="event">*/
/*           <div class="label">*/
/*             <img src="/assets/images/img4.png">*/
/*           </div>*/
/*           <div class="content">*/
/*             <div class="summary">*/
/*               <a>Joe Henderson</a> posted on his page*/
/*               <div class="date">*/
/*                 3 days ago*/
/*               </div>*/
/*             </div>*/
/*             <div class="extra text">*/
/*               Ours is a life of constant reruns. We're always circling back to where we'd we started, then starting all over again. Even if we don't run extra laps that day, we surely will come back for more of the same another day soon.*/
/*             </div>*/
/*             <div class="meta">*/
/*               <a class="like">*/
/*                 <i class="like icon"></i> 5 Likes*/
/*               </a>*/
/*             </div>*/
/*           </div>*/
/*         </div>*/
/*         <div class="event">*/
/*           <div class="label">*/
/*             <img src="/assets/images/img4.png">*/
/*           </div>*/
/*           <div class="content">*/
/*             <div class="summary">*/
/*               <a>Justen Kitsune</a> added <a>2 new photos</a> of you*/
/*               <div class="date">*/
/*                 4 days ago*/
/*               </div>*/
/*             </div>*/
/*             <div class="extra images">*/
/*               <a><img src="/assets/images/img1.png"></a>*/
/*               <a><img src="/assets/images/img1.png"></a>*/
/*             </div>*/
/*             <div class="meta">*/
/*               <a class="like">*/
/*                 <i class="like icon"></i> 41 Likes*/
/*               </a>*/
/*             </div>*/
/*           </div>*/
/*         </div>*/
/*       </div>*/
/*     </div>*/
/*   </div>*/
/* </div>*/
/* {% endblock %}*/
/* */
