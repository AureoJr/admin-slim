$(function(){
    /**
     * all response will be in below format
     * {
     *     success : boolean,
     *     data : {resource_object} or null,
     *     message : string,
     *     code : integer
     * }
     */

    var $loader = $('#loader');

    /**
     * reset the form and show it!
     */
    $('#btn-group-add').click(function(e){

        $('#group-form-data').each(function(){
            this.reset();
        });
        $('#btn-group-save').attr('data-method', 'POST');
        $('.ui.modal').modal({blurring: true}).modal('show');
    });

    /**
     * sen GET request to display resource with specific id, and display it in modal form
     */
    $('#group-table').on('click', '.ui.btn-editar', function(e){
        var $groupid = $(this).attr('data-id');

        $loader.show();

        $.get(global.baseUrl+'admin/group/'+$groupid, function(resp){
            if(resp.success){
                $('#group-form-data').each(function(){
                    this.reset();
                });

                var $group = resp.data;

                for(var a in $group){
                    $('#group_'+a).val($group[a]);
                }

                $('#btn-group-save').attr('data-method', 'PUT');
                  $('.ui.modal').modal({blurring: true}).modal('show');
            }else{
                alertify.error(resp.message);
                if(resp.code == 401){
                    location.reload();
                }
            }

            $loader.hide();
        });
    });

    /**
     * send DELETE request to the resouce server
     */
    $('#group-table').on('click', '.ui.btn-remover', function(e){
        var $groupid = $(this).attr('data-id');
        var strRemoverGrupo = 'Tem certeza que deseja remover esse grupo ?';
        if(alertify){
          alertify.confirm()
          .set('labels', {ok:'Sim!', cancel:'Não'})
            .setting({
              'title' : 'Remover Grupo',
              'message': strRemoverGrupo ,
              'onok': function(){
                $.ajax({
                    url    : global.baseUrl+'admin/group/'+$groupid,
                    method : 'DELETE',
                    data   : {
                        id : $groupid
                    },
                    success : function(resp){
                        if(resp.success){
                            alertify.success('Usuário removido com sucesso');
                            $('#group-row-'+$groupid).remove();
                        }else{
                            alertify.error(resp.message);
                            if(resp.code == 401){
                                location.reload();
                            }
                        }
                        $loader.hide();
                    }
                });
               },
              'onCancel': function(){ remove = false;}
            })
            .show();
        }
    });

    /**
     * send POST request to save data to resource server
     * or send PUT request to update data on resource server
     * based on data-method value
     */
    $('#btn-group-save').click(function(e){


        var $button = $(this),
            $groupdata = $('#group-form-data').serialize(),
            $method = $(this).attr('data-method'),
            $url = ($method == 'POST') ? global.baseUrl+'admin/group' : global.baseUrl+'admin/group/'+$('#group_id').val();

        $button.prop('disabled', true);
        $button.toggleClass('loading');
        $loader.show();

        $.ajax({
            url: $url,
            data: $groupdata,
            method : $method,
            success: function(resp){

                $button.prop('disabled', false);
                $button.toggleClass('loading');
                $loader.hide();

                if(resp.success){

                    group = resp.data;

                    if($method == 'POST'){
                        /** append group to new row */
                        $('#group-table').append(
                            '<tr id="group-row-'+resp.data.id+'">'+
                                '<td>'+group.id+'</td>'+
                                '<td>'+group.name+'</td>'+
                                '<td>'+group.description+'</td>'+
                                '<td>'+group.created_at+'</td>'+
                                '<td class="text-center">'+
                                  ' <button data-id="'+group.id+'"  class="ui mini teal basic button">'+
                                      '<i class="edit icon"></i> Editar '+
                                  ' </button>'+
                                  ' <button data-id="'+group.id+'"  class="ui mini red basic button">'+
                                      '<i class="remove icon"></i> Remover '+
                                  ' </button>'+

                                '</td>'+
                            '</tr>'
                        );
                        alertify.success('Grupo '+ group.name + ' cadastrado com sucesso' );
                    }else{
                        var $fields = $('#group-row-'+resp.data.id+' td');
                        $($fields[1]).html(group.name);
                        $($fields[2]).html(group.description);
                        $($fields[3]).html(group.created_at);
                    }

                    /** reset the form and hide modal form */
                    $('#group-form-data').each(function(){
                        this.reset();
                    });
                    $('.ui.modal').modal('hide');
                }else{
                      alertify.message(resp.message);
                    if(resp.code == 401){
                        location.reload();
                    }
                }
            }
        });
    });
});
