$(function(){
    /**
     * all response will be in below format
     * {
     *     success : boolean,
     *     data : {resource_object} or null,
     *     message : string,
     *     code : integer
     * }
     */

    var $loader = $('#loader');

    /**
     * reset the form and show it!
     */
    $('#btn-user-add').click(function(e){

        $('#user-form-data').each(function(){
            this.reset();
        });
        $('#btn-user-save').attr('data-method', 'POST');
        $('.ui.modal').modal({blurring: true}).modal('show');
    });

    /**
     * sen GET request to display resource with specific id, and display it in modal form
     */
    $('#user-table').on('click', '.ui.btn-editar', function(e){
        var $userid = $(this).attr('data-id');


        $loader.show();

        $.get(global.baseUrl+'admin/user/'+$userid, function(resp){
            if(resp.success){
                $('#user-form-data').each(function(){
                    this.reset();
                });

                var $user = resp.data;

                for(var a in $user){
                    $('#user_'+a).val($user[a]);
                }

                $('#btn-user-save').attr('data-method', 'PUT');
                  $('.ui.modal').modal({blurring: true}).modal('show');
            }else{
                alert(resp.message);
                if(resp.code == 401){
                    location.reload();
                }
            }

            $loader.hide();
        });
    });

    /**
     * send DELETE request to the resouce server
     */
    $('#user-table').on('click', '.ui.btn-remover', function(e){
        var $userid = $(this).attr('data-id');
        var strRemoverUsuario = 'Tem certeza que deseja remover esse usuário ?';
        if(alertify){
          alertify.confirm()
          .set('labels', {ok:'Sim!', cancel:'Não'})
            .setting({
              'title' : 'Remover Usuário',
              'message': strRemoverUsuario ,
              'onok': function(){
                $.ajax({
                    url    : global.baseUrl+'admin/user/'+$userid,
                    method : 'DELETE',
                    data   : {
                        id : $userid
                    },
                    success : function(resp){
                        if(resp.success){
                            alertify.success('Usuário removido com sucesso');
                            $('#user-row-'+$userid).remove();
                        }else{
                            alertify.error(resp.message);
                            if(resp.code == 401){
                                location.reload();
                            }
                        }
                        $loader.hide();
                    }
                });
               },
              'onCancel': function(){ remove = false;}
            })
            .show();
        } else {
          remove = confirm(strRemoverUsuario);
        }

    });

    /**
     * send POST request to save data to resource server
     * or send PUT request to update data on resource server
     * based on data-method value
     */
    $('#btn-user-save').click(function(e){


        var $button = $(this),
            $userdata = $('#user-form-data').serialize(),
            $method = $(this).attr('data-method'),
            $url = ($method == 'POST') ? global.baseUrl+'admin/user' : global.baseUrl+'admin/user/'+$('#user_id').val();

        $button.prop('disabled', true);
        $button.html('saving...');
        $loader.show();

        $.ajax({
            url: $url,
            data: $userdata,
            method : $method,
            success: function(resp){

                $button.prop('disabled', false);
                $button.toggleClass('loading');
                $loader.hide();

                if(resp.success){

                    user = resp.data;

                    if($method == 'POST'){
                        /** append user to new row */
                        $('#user-table').append(
                            '<tr id="user-row-'+resp.data.id+'">'+
                                '<td>'+user.id+'</td>'+
                                '<td>'+user.first_name+'</td>'+
                                '<td>'+user.last_name+'</td>'+
                                '<td>'+user.email+'</td>'+
                                '<td class="text-center">'+
                                  ' <button data-id="'+user.id+'"  class="ui mini teal basic button">'+
                                      '<i class="edit icon"></i> Editar '+
                                  ' </button>'+
                                  ' <button data-id="'+user.id+'"  class="ui mini red basic button">'+
                                      '<i class="remove icon"></i> Remover '+
                                  ' </button>'+

                                '</td>'+
                            '</tr>'
                        );
                    }else{
                        var $fields = $('#user-row-'+resp.data.id+' td');
                        $($fields[1]).html(user.first_name);
                        $($fields[2]).html(user.last_name);
                        $($fields[3]).html(user.email);
                    }

                    /** reset the form and hide modal form */
                    $('#user-form-data').each(function(){
                        this.reset();
                    });
                    $('.ui.modal').modal('hide');
                }else{
                    alert(resp.message);
                    if(resp.code == 401){
                        location.reload();
                    }
                }
            }
        });
    });
});
